import numpy as np
import math
import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *

class UIImage():
    def __init__(self):
        pass

    def Update(self, deltatime):
        pass
    
    def Render(self, screen):
        glWindowPos2d()
        if self.visible :
            pass
            #screen.blit(self.surf)
            